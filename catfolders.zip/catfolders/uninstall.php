<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb, $wp_version;
