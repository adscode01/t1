<?php
namespace CatFolders;

defined( 'ABSPATH' ) || exit;
class Plugin {
	public function __construct() {
	}

	public static function activate() {
	}

	public static function deactivate() {
	}
}
